#!/bin/bash


trap 'exit 0' SIGTERM
if [ -f "/etc/init.d/weixin" ]; then
    service weixin start
fi
# service nginx start
service sshd restart

while true;
do
    sleep 10
done
